import Foundation

/// Sends raw DNS messages to a DoH (DNS-over-HTTPS, RFC 8484) endpoint and
/// returns the raw DNS response. This is the core privacy mechanism: the
/// query leaves the device already encrypted inside a normal HTTPS POST,
/// so on-path observers (e.g. a captive ISP resolver) only see "HTTPS
/// traffic to cloudflare-dns.com", not the domain being looked up.
final class DoHResolver {
    private let session: URLSession

    init() {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 5
        self.session = URLSession(configuration: config)
    }

    /// Posts `dnsMessage` (raw wire-format DNS query bytes) to `server`'s
    /// DoH endpoint and returns the raw DNS response bytes, along with the
    /// round-trip latency in milliseconds. Usage: called once per parsed
    /// DNS request by PacketTunnelProvider.handleDNSPacket(_:).
    func resolve(dnsMessage: Data, using server: DoHServer) async throws -> (response: Data, latencyMs: Double) {
        var request = URLRequest(url: server.url)
        request.httpMethod = "POST"
        request.setValue("application/dns-message", forHTTPHeaderField: "Content-Type")
        request.setValue("application/dns-message", forHTTPHeaderField: "Accept")
        request.httpBody = dnsMessage

        let start = Date()
        let (data, response) = try await session.data(for: request)
        let latency = Date().timeIntervalSince(start) * 1000

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw DoHError.badResponse
        }
        return (data, latency)
    }

    enum DoHError: Error {
        case badResponse
    }
}
