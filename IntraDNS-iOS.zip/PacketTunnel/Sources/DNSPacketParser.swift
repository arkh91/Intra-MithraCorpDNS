import Foundation

/// Parses raw IP packets to pull out UDP/53 DNS payloads, and re-wraps DNS
/// responses back into IP/UDP packets to hand back to NEPacketTunnelFlow.
/// This is the iOS analog of Intra's Go-based `intra.SplitDNS` packet
/// handling on Android.
enum DNSPacketParser {

    /// One parsed DNS request pulled out of an IP packet.
    struct ParsedRequest {
        let dnsPayload: Data       // raw DNS message (question section etc.)
        let sourceIP: Data         // original source IP, needed to build the reply
        let sourcePort: UInt16
        let destIP: Data
        let destPort: UInt16
        let isIPv4: Bool
    }

    /// Attempts to extract a DNS request from a raw IP packet read from the
    /// tunnel flow. Usage: called once per packet in
    /// PacketTunnelProvider.readPackets(); returns nil for anything that
    /// isn't a UDP/53 DNS query (e.g. TCP traffic, non-DNS UDP), which the
    /// caller should pass through untouched.
    static func parse(packet: Data, isIPv4: Bool) -> ParsedRequest? {
        guard packet.count > 28 else { return nil } // min IPv4+UDP header size

        if isIPv4 {
            let ihl = Int(packet[0] & 0x0F) * 4
            guard packet.count > ihl + 8 else { return nil }
            let proto = packet[9]
            guard proto == 17 else { return nil } // UDP
            let srcIP = packet.subdata(in: 12..<16)
            let dstIP = packet.subdata(in: 16..<20)
            let udpStart = ihl
            let srcPort = UInt16(packet[udpStart]) << 8 | UInt16(packet[udpStart + 1])
            let dstPort = UInt16(packet[udpStart + 2]) << 8 | UInt16(packet[udpStart + 3])
            guard dstPort == 53 else { return nil }
            let dnsPayload = packet.subdata(in: (udpStart + 8)..<packet.count)
            return ParsedRequest(dnsPayload: dnsPayload, sourceIP: srcIP, sourcePort: srcPort,
                                  destIP: dstIP, destPort: dstPort, isIPv4: true)
        } else {
            // IPv6 fixed header is 40 bytes; assumes no extension headers,
            // which covers the vast majority of real-world DNS traffic.
            guard packet.count > 48 else { return nil }
            let nextHeader = packet[6]
            guard nextHeader == 17 else { return nil }
            let srcIP = packet.subdata(in: 8..<24)
            let dstIP = packet.subdata(in: 24..<40)
            let udpStart = 40
            let srcPort = UInt16(packet[udpStart]) << 8 | UInt16(packet[udpStart + 1])
            let dstPort = UInt16(packet[udpStart + 2]) << 8 | UInt16(packet[udpStart + 3])
            guard dstPort == 53 else { return nil }
            let dnsPayload = packet.subdata(in: (udpStart + 8)..<packet.count)
            return ParsedRequest(dnsPayload: dnsPayload, sourceIP: srcIP, sourcePort: srcPort,
                                  destIP: dstIP, destPort: dstPort, isIPv4: false)
        }
    }

    /// Builds a fake IP/UDP reply packet carrying `dnsResponse`, addressed
    /// back to the original requester (source becomes the old destination
    /// and vice versa). Usage: called by PacketTunnelProvider after a DoH
    /// response comes back, right before writing it to the tunnel flow so
    /// the OS delivers it to the app that made the original query.
    static func buildReply(to request: ParsedRequest, dnsResponse: Data) -> Data {
        var packet = Data()
        if request.isIPv4 {
            var header = Data(count: 20)
            header[0] = 0x45 // version 4, IHL 5
            let totalLength = UInt16(20 + 8 + dnsResponse.count)
            header[2] = UInt8(totalLength >> 8); header[3] = UInt8(totalLength & 0xFF)
            header[8] = 64  // TTL
            header[9] = 17  // UDP
            header.replaceSubrange(12..<16, with: request.destIP)   // reply source = original dest
            header.replaceSubrange(16..<20, with: request.sourceIP) // reply dest = original source
            packet.append(header)
        } else {
            var header = Data(count: 40)
            header[0] = 0x60
            let payloadLength = UInt16(8 + dnsResponse.count)
            header[4] = UInt8(payloadLength >> 8); header[5] = UInt8(payloadLength & 0xFF)
            header[6] = 17 // next header UDP
            header[7] = 64 // hop limit
            header.replaceSubrange(8..<24, with: request.destIP)
            header.replaceSubrange(24..<40, with: request.sourceIP)
            packet.append(header)
        }
        var udp = Data(count: 8)
        udp[0] = UInt8(request.destPort >> 8); udp[1] = UInt8(request.destPort & 0xFF)
        udp[2] = UInt8(request.sourcePort >> 8); udp[3] = UInt8(request.sourcePort & 0xFF)
        let udpLength = UInt16(8 + dnsResponse.count)
        udp[4] = UInt8(udpLength >> 8); udp[5] = UInt8(udpLength & 0xFF)
        // Checksum left as 0 (valid for UDP over IPv4 as "no checksum computed";
        // IPv6 requires a real checksum in production — compute one before
        // shipping if you see clients silently dropping replies).
        packet.append(udp)
        packet.append(dnsResponse)
        return packet
    }

    /// Extracts the queried domain name from a raw DNS message, for display
    /// in QueryLogView. Usage: called by PacketTunnelProvider right before
    /// logging each resolved query.
    static func extractDomain(from dnsPayload: Data) -> String? {
        guard dnsPayload.count > 12 else { return nil }
        var offset = 12
        var labels: [String] = []
        while offset < dnsPayload.count {
            let length = Int(dnsPayload[offset])
            if length == 0 { break }
            offset += 1
            guard offset + length <= dnsPayload.count else { return nil }
            let labelData = dnsPayload.subdata(in: offset..<(offset + length))
            labels.append(String(data: labelData, encoding: .utf8) ?? "")
            offset += length
        }
        return labels.isEmpty ? nil : labels.joined(separator: ".")
    }
}
