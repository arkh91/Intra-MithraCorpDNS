import NetworkExtension
import Foundation

/// The actual VPN tunnel. iOS routes all device DNS traffic through this
/// extension once the tunnel is active; every UDP/53 packet is intercepted
/// here, its DNS payload is re-sent over DoH, and the response is written
/// back so the OS delivers it to whichever app made the original query.
/// This mirrors Intra's Android VpnService.Builder + Go `intra` tunnel core.
class PacketTunnelProvider: NEPacketTunnelProvider {

    private let resolver = DoHResolver()
    private var currentServer: DoHServer = AppGroupStore.shared.selectedServer()

    /// Called by iOS when the user (via TunnelManager) starts the tunnel.
    /// Sets up the virtual network interface and begins reading packets.
    override func startTunnel(options: [String : NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        currentServer = AppGroupStore.shared.selectedServer()

        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        // Route all DNS to us by claiming a private tunnel IP and setting
        // ourselves as the DNS server; everything else routes normally.
        settings.ipv4Settings = NEIPv4Settings(addresses: ["10.0.0.2"], subnetMasks: ["255.255.255.0"])
        settings.ipv4Settings?.includedRoutes = [NEIPv4Route.default()]
        settings.dnsSettings = NEDNSSettings(servers: ["10.0.0.2"])
        settings.dnsSettings?.matchDomains = [""] // apply to all domains
        settings.mtu = 1500

        setTunnelNetworkSettings(settings) { [weak self] error in
            guard let self else { return }
            if let error {
                completionHandler(error)
                return
            }
            self.readPackets()
            completionHandler(nil)
        }
    }

    /// Called by iOS when the user (via TunnelManager) stops the tunnel, or
    /// the system needs to tear it down (e.g. app updated, low memory).
    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        completionHandler()
    }

    /// Continuously reads packets from the virtual interface. Usage: kicked
    /// off once by startTunnel(); re-schedules itself after each batch so it
    /// keeps running for the lifetime of the tunnel.
    private func readPackets() {
        packetFlow.readPackets { [weak self] packets, protocols in
            guard let self else { return }
            for (index, packet) in packets.enumerated() {
                let isIPv4 = protocols.indices.contains(index) ? protocols[index].int32Value == AF_INET : true
                self.handle(packet: packet, isIPv4: isIPv4)
            }
            self.readPackets() // keep the read loop alive
        }
    }

    /// Routes a single packet: DNS queries get intercepted and resolved via
    /// DoH; everything else is passed straight through unmodified so normal
    /// app traffic (web browsing, etc.) isn't affected.
    /// Usage: called once per packet from readPackets() above.
    private func handle(packet: Data, isIPv4: Bool) {
        guard let request = DNSPacketParser.parse(packet: packet, isIPv4: isIPv4) else {
            // Not a DNS packet — pass through untouched.
            packetFlow.writePackets([packet], withProtocols: [NSNumber(value: isIPv4 ? AF_INET : AF_INET6)])
            return
        }
        Task { await self.resolveAndReply(request: request, isIPv4: isIPv4) }
    }

    /// Sends the parsed DNS request out over DoH, writes the reply back
    /// into the tunnel, and logs the result for QueryLogView/MapView.
    /// Usage: called once per intercepted DNS packet from handle(packet:).
    private func resolveAndReply(request: DNSPacketParser.ParsedRequest, isIPv4: Bool) async {
        do {
            let (response, latencyMs) = try await resolver.resolve(dnsMessage: request.dnsPayload, using: currentServer)
            let reply = DNSPacketParser.buildReply(to: request, dnsResponse: response)
            packetFlow.writePackets([reply], withProtocols: [NSNumber(value: isIPv4 ? AF_INET : AF_INET6)])
            logQuery(request: request, dnsResponse: response, latencyMs: latencyMs)
        } catch {
            // On failure we simply drop the query rather than falling back
            // to plaintext DNS, since that would defeat the whole purpose.
        }
    }

    /// Parses out the domain + resolved IPs from the raw response and
    /// writes a QueryLogEntry to the shared App Group store.
    /// Usage: called once per successfully resolved query, right after
    /// writing the reply packet.
    private func logQuery(request: DNSPacketParser.ParsedRequest, dnsResponse: Data, latencyMs: Double) {
        let domain = DNSPacketParser.extractDomain(from: request.dnsPayload) ?? "unknown"
        let ips = extractAnswerIPs(from: dnsResponse)
        let entry = QueryLogEntry(id: UUID(), domain: domain, resolvedIPs: ips,
                                   latencyMs: latencyMs, timestamp: Date(),
                                   serverID: currentServer.id, latitude: nil, longitude: nil)
        AppGroupStore.shared.appendLog(entry)
    }

    /// Minimal DNS answer-section parser to pull A-record IPs out of a raw
    /// response, for display purposes only (not used for routing decisions).
    /// Usage: called by logQuery(request:dnsResponse:latencyMs:).
    private func extractAnswerIPs(from response: Data) -> [String] {
        guard response.count > 12 else { return [] }
        let answerCount = Int(response[6]) << 8 | Int(response[7])
        guard answerCount > 0 else { return [] }
        var ips: [String] = []
        var offset = 12
        // Skip the question section (name + type(2) + class(2)).
        while offset < response.count, response[offset] != 0 {
            offset += Int(response[offset]) + 1
        }
        offset += 5
        for _ in 0..<answerCount {
            guard offset + 12 <= response.count else { break }
            // Skip name pointer(2) + type(2) + class(2) + ttl(4) = 10, then read rdlength(2).
            let rdLengthOffset = offset + 10
            guard rdLengthOffset + 2 <= response.count else { break }
            let rdLength = Int(response[rdLengthOffset]) << 8 | Int(response[rdLengthOffset + 1])
            let rdataOffset = rdLengthOffset + 2
            guard rdataOffset + rdLength <= response.count else { break }
            if rdLength == 4 {
                let bytes = response.subdata(in: rdataOffset..<(rdataOffset + 4))
                ips.append(bytes.map { String($0) }.joined(separator: "."))
            }
            offset = rdataOffset + rdLength
        }
        return ips
    }
}
